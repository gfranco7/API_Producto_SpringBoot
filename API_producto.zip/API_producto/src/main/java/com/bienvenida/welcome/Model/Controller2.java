package com.bienvenida.welcome.Model;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

public class Controller2 {
    @Controller
    public static class Controller1 {
        @ResponseBody
        @GetMapping("/api/producto")
        public String saludar(Model model) {
            model.addAttribute("producto", "ferrrari");
            model.addAttribute("precio", "5000000");
            model.addAttribute("descripcion", "la ferrrari");
            return model.toString();
        }
    }
}
